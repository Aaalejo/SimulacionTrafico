import { forwardRef } from "react";
import './Car.sass'

const Car = forwardRef(function Car({ ...props }, ref) {
  return (
      <div className="car" ref={ref} {...props}>
      </div>
  );
});

export default Car;
