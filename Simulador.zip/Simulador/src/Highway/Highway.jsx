import React from 'react';
import './Highway.sass';

const Highway = ({ children, axis }) => {
  return (
    <div className={`Highway Highway__${axis}`}>
      {children}
    </div>
  );
}
 
export default Highway;