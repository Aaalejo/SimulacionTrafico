import { useState, useRef, useEffect } from 'react'
import './App.sass'
import Car from './Car'
import TrafficLight from './TrafficLight'
import Highway from './Highway'

function App() {
  const [ lightX, setLightX ] = useState('')
  const [ lightY, setLightY ] = useState('')
  const highwayXref = useRef(null)
  const highwayYref = useRef(null)
  const [xFinish, setXFinish] = useState(false)

  function handleStart() {
    setLightX('green')
    setLightY('red')
  }

  function handleReload() {
    location.reload()
  }

  useEffect(() => {
    if(lightX === 'green' && !xFinish) {
      highwayXref.current.style.left = '30%'
      setXFinish(true)
    }

    if(xFinish) {
      highwayXref.current.style.transitionTimingFunction = 'linear'
    } 

    if(lightX === 'green' && xFinish) {
      highwayXref.current.style.left = '100%'
    }
  }, [lightX])

  useEffect(() => {
    if(lightY === 'green') {
      highwayYref.current.style.bottom = '110%'
    }
  }, [lightY])

  return (
    <>
      <div className='corner corner_1'>
        <button onClick={handleStart}>Comenzar</button>
        <button onClick={handleReload}>Reiniciar</button>
      </div>
      <div className='corner corner_2'></div>
      <div className='corner corner_3'></div>
      <div className='corner corner_4'></div>

      <Highway axis='x'>
        <TrafficLight light={lightX} setLight={setLightX}/>
        <Car light={lightX} direction={'x'} ref={highwayXref}/>
      </Highway>
      <Highway axis='y'>
        <TrafficLight light={lightY} setLight={setLightY}/>
        <Car light={lightY} direction={'y'} ref={highwayYref} />
      </Highway>
    </>
  )
}

export default App
