import { useEffect } from 'react';
import './TrafficLight.sass'

const Sign = ({ color, off }) => {
  const colorClassName = `traffic-light__sign--${off ? 'off' : color}`
  return (
    <div className={`traffic-light__sign ${colorClassName}`}>
    </div>
  );
}

const TrafficLight = ({ light, setLight }) => {
  // Time in ms
  const redTime = 7 * 1000
  const yellowTime = 2 * 1000
  const greenTime = 5 * 1000

  useEffect(() => {
    let timeoutID = null
    if(light === 'red') {
      timeoutID = setTimeout(() => {
        setLight('green')
      }, redTime)
    }

    if(light === 'green') {
      timeoutID = setTimeout(() => {
        setLight('yellow')
      }, greenTime)
    }

    if(light === 'yellow') {
      timeoutID = setTimeout(() => {
        setLight('red')
      }, yellowTime)
    }

    return () => {
      clearTimeout(timeoutID)
    }
  }, [light])

  return (
    <div className="traffic-light">
      <Sign color={'red'} off={light !== 'red'} />
      <Sign color={'yellow'} off={light !== 'yellow'}/>
      <Sign color={'green'} off={light !== 'green'}/>
    </div>
  );
}
 
export default TrafficLight;